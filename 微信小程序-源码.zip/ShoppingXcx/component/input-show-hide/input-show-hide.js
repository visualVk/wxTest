Component({
    /**
     * 组件的属性列表
     */
    properties: {
        inputPlaceHolder: {
            type: String,
            value: ''
        },
        inputType: {
            type: String,
            value: 'text'
        },
        isPassword: {
            type: Boolean,
            value: true
        },
        placeholderClass:{
            type: String,
            value:''
        },
        inputValue: String,
    },

    /**
     * 组件的初始数据
     */
    data: {
            isClearShow:false,
            isPassword: true
    },

    /**
     * 组件的方法列表
     */
    methods: {
        inputClick:function (e) {
            var value = e.detail.value
            if(value==null || value==undefined || value.length==0){
                this.setData({
                    isClearShow:false
                })
            }else{
                this.setData({
                    isClearShow:true
                })
            }
            var detail = {
                value: value,
            };
            this.triggerEvent('inputClick', detail);
        },
        // blurClick:function(e){
        //     var value = e.detail.value
        //     this.setData({
        //         isClearShow:false
        //     })
        //     var detail = {
        //         value: value,
        //     };
        //     this.triggerEvent('blurClick', detail);
        // },
        // focusClick:function(e){
        //     var value = e.detail.value
        //     if(value==null || value==undefined || value.length==0) {
        //         this.setData({
        //             isClearShow: false
        //         })
        //     }else{
        //         this.setData({
        //             isClearShow: true
        //         })
        //     }
        //     var detail = {
        //         value: value,
        //     };
        //     this.triggerEvent('focusClick', detail);
        // },

        blurClick: function (e) {
            this.setData({
                inputValue: e.detail.value
            })
        },
        SHTap:function () {
            this.setData({
                isPassword:!this.data.isPassword
            })
            console.log("isPassword:" + this.data.isPassword)
        }
    }
})