// pages/addShop/addShop.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array:['餐饮','运动'],
    index:0,
    Array:[{name:'餐饮',id:0},{name:'运动',id:1}],
    shopName:'',
    shopDesc:'',
    shopTime:'',
    address:'',
    spend:'',
    latitude:'',
    longitude:'',
    phone:'',
    imageUrl:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  chooseImg:function(){
    let that = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        const tempFilePaths = res.tempFilePaths
        const fs = wx.getFileSystemManager()
        fs.readFile({
          filePath : tempFilePaths[0],
          encoding : 'base64',
          success:function(data){
            app.post({
              url:'apprise/uploadImage',
              data:{
                img : data.data
              }
            }).then(res=>{
              that.setData({
                imageUrl : res.url
              })
              app.toast.fail('上传成功')
            }).catch(()=>{
              app.toast.fail('上传失败')
            })
          }
        })

      }
    });
  },


  getShopName:function(e){
    let name = e.detail.value
    this.setData({
      shopName : name
    })
  },

  getShopDesc:function(e){
    let name = e.detail.value
    this.setData({
      shopDesc : name
    })
  },
  getShopTime:function(e){
    let name = e.detail.value
    this.setData({
      shopTime : name
    })
  },
  getAddress:function(e){
    let name = e.detail.value
    this.setData({
      address : name
    })
  },
  getSpend:function(e){
    let name = e.detail.value
    this.setData({
      spend : name
    })
  },
  getLatitude:function(e){
    let name = e.detail.value
    this.setData({
      latitude : name
    })
  },
  getLongitude:function(e){
    let name = e.detail.value
    this.setData({
      longitude : name
    })
  },
  getPhone:function(e){
    let name = e.detail.value
    this.setData({
      phone : name
    })
  },

  myIsNaN:function(value) {
  return typeof value === 'number' && !isNaN(value);
  },

   Number:function(val) {
  if (parseFloat(val).toString() == "NaN") {

    return false;
  } else {
    return true;
  }
},

  confirm:function(){
    if(this.Number(this.data.spend)&&this.Number(this.data.longitude)&&this.Number(this.data.latitude)){
      app.post({
        url:'shop/insertShop',
        data:{
          shopName : this.data.shopName,
          shopDetail : this.data.shopDesc,
          shopTime : this.data.shopTime,
          shopAddress : this.data.address,
          spend : this.data.spend,
          shopImg : this.data.imageUrl,
          lg : this.data.longitude,
          la : this.data.latitude,
          phone : this.data.phone,
          shopType: this.data.Array[this.data.index].name
        }
      }).then(res=>{
        wx.navigateBack()
        app.toast.fail('成功')
      })
    }else{
      app.toast.fail('人均需要为数字')
    }

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
