//index.js
//获取应用实例
const app = getApp()
let QQMapWX = require('../../utils/qqmap-wx-jssdk.min.js');
let qqmapsdk = null;
Page({
  data: {
    indicatorDots: true, //是否显示面板指示点
    autoplay: true, //是否自动播放
    interval: 5000, //停留时间间隔
    duration: 1000, //播放时长
    previousMargin: '40px', //前边距，可用于露出前一项的一小部分，接受 px 和 rpx 值
    nextMargin: '40px', //后边距，可用于露出后一项的一小部分，接受 px 和 rpx 值
    circular: true, //是否采用衔接滑动
    currentSwiperIndex: 0, //swiper当前索引
    imageList:['../../img/icon/hanbaowang.jpg',
      'https://www.zrwl2018.cn/egoshe-api/rcode/img/qietu/b1.png',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1569403435252&di=e9b9d49d51a56fca2802248f52f9f07e&imgtype=0&src=http%3A%2F%2Fp1.meituan.net%2Fdeal%2F967a5387927abf82c3a1324c4b84be8d100685.jpg',],
    pageNum:1,
    pageSize: 5,
    shopList: [],
    loadMore:true
  },

  onLoad:function(){
    this.getList()
    this.initMap()
  },



  swiperBindchange(e) {
    this.setData({
      currentSwiperIndex: e.detail.current
    })
  },

  toSearch:function () {
    wx.navigateTo({
      url: '/pages/search/search'
    })
  },

  getList:function (t) {
    if(this.data.loadMore == false){
      return;
    }
    wx.showLoading({
      title:'加载中'
    })
    app.post({
      url:'shop/getList',
      data:{
        pageNum : this.data.pageNum,
        pageSize : this.data.pageSize
      }
    }).then(res=>{
      wx.hideLoading()
      if(this.data.pageSize>res.shopList.length){
        this.setData({
          loadMore : false
        })
      }else{
        this.setData({
          loadMore : true
        })
      }
      if(t==1){
        this.setData({
          shopList : this.data.shopList.concat( res.shopList)
        })
      }else{
        this.setData({
          shopList : res.shopList
        })
      }

    }).catch(err=>{
      wx.hideLoading()
      console.log('fail')
    })
  },

  initMap : function () {
    return new Promise(((resolve, reject) => {
      qqmapsdk = new QQMapWX({
        //小程序申请的QQMapKey
        key: '6X7BZ-Z5UCI-NJ3G7-5EXDZ-NXWU2-SFFCY'
      });
      wx.getLocation({
        type: 'wgs84',
        success: (res) => {
          app.globalData.latitude = res.latitude;
          app.globalData.longitude = res.longitude;
          resolve(res)
        },
        fail: err => {
          //如果用户点了取消，没有获取位置
          let that = this
          wx.getSetting({
            success: function (res) {
              let statu = res.authSetting;
              if (!statu['scope.userLocation']) {
                wx.showModal({
                  title: '是否授权当前位置',
                  content: '需要获取您的地理位置，请确认授权，否则地图功能将无法使用',
                  success: function (tip) {
                    if (tip.confirm) {
                      wx.openSetting({
                        success: function (data) {
                          if (data.authSetting["scope.userLocation"] === true) {
                            wx.showToast({
                              title: '授权成功',
                              icon: 'success',
                              duration: 1000
                            })
                            //授权成功之后，再调用getLocation获取当前位置
                            wx.getLocation({
                              success: function(res) {
                                app.globalData.latitude = res.latitude;
                                app.globalData.longitude = res.longitude;
                                that.setData({
                                  locationAuth :false
                                })
                                this.getProjectList('','')
                                resolve(res)
                              },
                            })
                          } else {
                            wx.showToast({
                              title: '授权失败',
                              icon: 'success',
                              duration: 1000
                            })
                            that.setData({
                              locationAuth :true
                            })
                          }
                        },fail : err=>{
                          that.setData({
                            locationAuth :true
                          })
                        }
                      })
                    }
                  }
                })
              }
            },
            fail: function (res) {
              wx.showToast({
                title: '调用授权窗口失败',
                icon: 'success',
                duration: 1000
              })
            }
          })
          reject(err);
        }
      })
    }));
  },

  onReachBottom: function () {
    let num = this.data.pageNum + 1
    this.setData({
      pageNum : num
    })
      this.getList(1)
  },


})
