// pages/login/login.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    plain: true,
    userAccount: '',
    userPwd: '',
    isClearShow: false,
    isClearShow2: false,
    floorstatus: true,
    cardNum:'',
    cardId:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  toForget: function () {

  },
  //登录按钮
  login_btn: function () {
    let myreg = /^((1)+\d{10})$/;
    let userAccount = this.data.userAccount;
    let userPwd = this.data.userPwd;
    // if (!myreg.test(userAccount)) {
    //   app.toast.fail("手机号码有误");
    // } else if (userPwd == '') {
    //   app.toast.fail("密码不能为空");
    // } else {

    // }
    this.login()
  },
  login:function() {
    //网络请求
    app.post({
      url:'user/login',
      data:{
        username : this.data.userAccount,
        password : this.data.userPwd
      }
    }).then(res=>{
      app.globalData.user = res.user
      wx.setStorageSync('user', res.user);
      wx.showToast({
        title: '登录成功',
        duration: 2000
      })
      wx.switchTab({
        url: '/pages/index/index'
      })
    }).catch(err=>{
      app.toast.fail(err.message || '请求失败')
    })
  },





  //获取用户输入的手机号
  getAccount: function (e) {
    let value = e.detail.value
    this.setData({
      userAccount: value
    })
    // console.log(this.data.userAccount)
  },
  //获取用户的密码
  getPwd: function (e) {
    var value = e.detail.value
    this.setData({
      userPwd: e.detail.value
    })
  },

    register:function(){
      wx.navigateTo({
        url: '/pages/register/register'
      })
    },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
