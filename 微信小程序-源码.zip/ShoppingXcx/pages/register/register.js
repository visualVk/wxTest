// pages/register/register.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userAccount:'',
    newPwd:'',
    newPwdAgain:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  getAccount:function(e){
    let account = e.detail.value
    this.setData({
      userAccount : account
    })
  },

  getNewPwd:function(e){
    let newPwd = e.detail.value
    this.setData({
      newPwd : newPwd
    })
  },

  getNewPwdAgain:function(e){
    let newPwdAgain = e.detail.value
    this.setData({
      newPwdAgain : newPwdAgain
    })
  },

  confirm:function(){
    if(this.data.newPwd === this.data.newPwdAgain){
      this.register()
    }else{
      app.toast.fail('密码不一致')
    }
  },

  register:function(){
    app.post({
      url:'user/register',
      data:{
        username: this.data.userAccount,
        password : this.data.newPwd
      }
    }).then(res=>{
      setTimeout(function () {
        wx.navigateBack()
      },1000)
      wx.showToast({
        title: '注册成功'
      })
    }).catch(err=>{
      app.toast.fail(err.data || '请求失败')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
