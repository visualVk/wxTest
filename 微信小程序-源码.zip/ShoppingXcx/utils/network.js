/**network.js */
const app = getApp()
var baseUrl = 'http://localhost:8080/shopping/'
var isFail = false;
//GET请求
function GET(requestHandler) {
  // request('GET', requestHandler)
  return new Promise((resolve,reject) => {
    var params = requestHandler.data || {};

    let keys = Object.keys(params)
    if (keys.indexOf('token') && !wx.getStorageSync('token') && wx.getStorageSync('token') != '') {
      //防止登陆过程中已经跳转，但是未及时取到token造成的报错
      let setInter = setInterval(() => {
        let token = wx.getStorageSync('token')
        if (token) {
          requestHandler.params.token = token
          clearInterval(setInter)
          request('GET', requestHandler).then(res => {
              resolve(res)
          }).catch(err => {
            reject(err)
          })
        }
      }, 50)
    } else {
      request('GET', requestHandler).then(res => {
        resolve(res)
      }).catch(err => {
        reject(err)
      })
    }
  })

}
//POST请求
function POST(requestHandler) {
  return new Promise((resolve,reject) => {
      request('POST', requestHandler).then(res => {
        resolve(res)
      }).catch(err => {
        reject(err)
      })
  })

}


function request(method, requestHandler) {

  //注意：可以对params加密等处理
return new Promise((resolve,reject) => {
  var params = requestHandler.data;
  var url = baseUrl + requestHandler.url;
  // console.log(JSON.stringify(params), 'json 数据')
  console.log(params, url + '==>提交的数据')
  wx.request({
    url: url,
    data: params,
    method: method,
    dataType: 'json',
    header: {
      'content-type': 'application/x-www-form-urlencoded;charset=utf-8"'
    },
    success: (res) => {
      //注意：可以对参数解密等处理
      console.log(res.data.msg)
      if (res.data.msg == 'success') {
        console.log(res.data, url + '==>成功返回数据');
        // requestHandler.success(res.data);
        resolve(res.data)
      }  else {
        console.log(res.data, url + '==>失败返回数据')
        // requestHandler.fail(res.data);
        reject(res.data)
      }
    },
    fail: function (fail) {
      reject(fail)
    },
    complete: function () {
      // complete
    }
  })
})

}


module.exports = {
  get: GET,
  post: POST
}
